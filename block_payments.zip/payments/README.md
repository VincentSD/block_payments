# moodle-block_payments
A simple test block showing off some moodle functionality

This block was created as part of a series of tutorial videos you can find here:
https://www.youtube.com/watch?v=Dy_1LueyAxo

Each commit should line up to the code at the end of the video.

Enjoy
